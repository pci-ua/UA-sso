<!DOCTYPE html>
<html lang="fr">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="{{ asset('css/app.css')}}">
   <style>
    .monasso{
        padding: 20px;
    }
    .afficherevenement{
        display: flex;
        flex-direction: column;
    }
    .produit{
        display: flex;
        align-items: center;
    }
    .gestion{
        display: flex;
        width: 100%;
        justify-content: space-around;
    }
    .gestionstock{
        display: flex;
        flex-direction: column;
        align-items: center;
        padding-top: 25px;
    }
    .suppr{
        display: flex;
        padding-top: 100px;
        justify-content: center;
        align-content: center;
    }
    .zonenbr {
        width: 50px;
    }
    .barregauche{
        border-left: solid;
        height: 100%;
        width: 50%;
    }
    .espace {
        margin-top: 50px;
        padding-top: 10px;
    }
    .barre {
        border-top: solid;
        margin-top: 50px;
    }
</style>

    <script src="https://cdn.rawgit.com/davidshimjs/qrcodejs/gh-pages/qrcode.min.js"></script>

   <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>

   <title>Projet Asso gestion Event </title>
</head>

<body >
    @include('menu')
    @yield('content')

    @include('footer')
</body>
    
</html>