
@extends('gabari')


@section('content')

<section class="gestionstock">
@include('partiestock')
</section>

<section class="gestion barre">
    @include('partiemessage')

    @include('partiegestionparticipant')
</section>

@include('partiesupprevent')
@endsection
