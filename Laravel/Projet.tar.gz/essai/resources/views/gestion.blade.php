
@extends('gabari')


@section('content')


@include('partiestock')

@include('partiemessage')

@endsection