@extends('gabari')

@section('content')
<h1>Invitation</h1>
<form action="{{ url('/')}}/{{$identifier}}/inviterAssociation" method="post" id="invitation-form">
    @csrf
    <h3>Nom:<input type="text" id="nom" name="nom"/>&nbsp;&nbsp;&nbsp;</h3>&nbsp;&nbsp;&nbsp;<h3>
    <h3>Prenom:<input type="text" id="prenom" name="prenom"/>&nbsp;&nbsp;&nbsp;</h3>&nbsp;&nbsp;&nbsp;<h3><div id="personne-info"></div></h3>
    <br><br><br>
    <h2>Liste de vos associations:</h2>
    <select name="asso">
        <option value="---" selected>---</option>
        @foreach ($listeass as $n)
        <option value="{{$n}}">{{$n}}</option>
        @endforeach
    </select>
    <br><br><br>
    <input type="submit" value="Inviter!" id="submit-button"/>
</form>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>

    const lastname = document.getElementById('nom');
const firstname = document.getElementById('prenom');
const nameDiv = document.getElementById('personne-info');

firstname.addEventListener('input', function() {
  const nom = lastname.value;
  const prenom = firstname.value;
  if (nom && prenom) {
    fetch(`/get-person-info-ajax/${encodeURIComponent(nom)}/${encodeURIComponent(prenom)}`)
      .then(response => response.json())
      .then(data => {
        let html = '';
        if (data.length > 0) {
            if(data.length>1){
                html +=`Oups!Il semble y avoir plusieurs personnes avec le nom et le prénom indiqués...Veuillez en sélectionner une:<br>`;
                    data.forEach(({ Nom, Prenom, mail, Filiere,id,identifiant }) => {
            html += `
            <input type="radio" name="plusieurspersonnes" value="${id}"> Nom et prénom:${Nom} ${Prenom} ; Mail: ${mail} ; Filiere : ${Filiere} ; Identifiant :${identifiant} <br>`;
          });

            }
            else{
          data.forEach(({ Nom, Prenom, mail, Filiere }) => {
            html += `
              <p>
                Nom et Prénom: ${Prenom} ${Nom}<br>
                e-mail:${mail}<br>
                Filière actuelle: ${Filiere}<br>
              </p>
            `;
          });
        }
    }
    else {
          html = 'Aucune personne trouvée avec le nom et le prénom fournis.';
        }
        nameDiv.innerHTML = html;
      })
      .catch(error => {
        console.error('Error:', error);
      });
  } else {
    nameDiv.textContent = '';
  }
});

lastname.addEventListener('input', function() {
    if (nom && prenom) {
    fetch(`/get-person-info-ajax/${encodeURIComponent(nom)}/${encodeURIComponent(prenom)}`)
      .then(response => response.json())
      .then(data => {
        let html = '';
        if (data.length > 0) {
            if(data.length>1){
                html +=`Oups!Il semble y avoir plusieurs personnes avec le nom et le prénom indiqués...Veuillez en sélectionner une:<br>`;
                    data.forEach(({ Nom, Prenom, mail, Filiere,id,identifiant }) => {
            html += `
            <input type="radio" name="plusieurspersonnes" value="${id}"> Nom et prénom:${Nom} ${Prenom} ; Mail: ${mail} ; Filiere : ${Filiere} ; Identifiant :${identifiant} <br>`;
          });

            }
            else{
          data.forEach(({ Nom, Prenom, mail, Filiere }) => {
            html += `
              <p>
                Nom et Prénom: ${Prenom} ${Nom}<br>
                e-mail:${mail}<br>
                Filière actuelle: ${Filiere}<br>
              </p>
            `;
          });
        }
    }
    else {
          html = 'Aucune personne trouvée avec le nom et le prénom fournis.';
        }
        nameDiv.innerHTML = html;
      })
      .catch(error => {
        console.error('Error:', error);
      });
  } else {
    nameDiv.textContent = '';
  }
});



</script>

@endsection
