<div id="qrcode"></div>

<script>
    // hashage
    function hashFunction(data) {
        // base64
        const Hash = btoa(data);

        return Hash; 
    }

    function reverse(data){
        return atob(data);
    }

    
    var Url=window.location.pathname;
    const data = Url.split('/')[1];
    const hashedData = hashFunction(data); // Remplacez "hashFunction" par la fonction de hachage que vous utilisez
    const qrCode = new QRCode(document.getElementById("qrcode"), {
    text: hashedData,
    width: 200,
    height: 200
    });

    console.log('Partie Qr');
    console.log('le cryptage: '+hashedData);
    console.log('l\'info original (l\'identifiant): '+reverse(hashedData));
    console.log('___________');
</script>