<header>
    @if (isset($personne))
        <h1 id="NomUtilisateur"> {{$personne->Prenom}} {{$personne['Nom']}}</h1>
        
    @else
        <h1> Projet Gestion Événement</h1>
    @endif
    @if (isset($personne))
    <ul>
        @if (isset($pageprincipale))
            <a href="#event"><li>Événement</li></a>
            <a href="#asso"><li>Association</li></a>
        @else
            <a href="{{url('/')}}/{{$personne['Identifiant']}}#event"><li>Événement</li></a>
            <a href="{{url('/')}}/{{$personne['Identifiant']}}#asso"><li>Association</li></a>
        @endif
        <a href="{{url('/')}}/{{$personne->Identifiant}}/Profil"><li>Mon Compte</li></a>
        <div class="dropdown">
            <p>Action</p>
            <div class="dropdown-child">
              <a href="{{url('/')}}/{{$personne['Identifiant']}}/inviterAssociation">Inviter</a>
              <a href="{{url('/')}}/{{$personne['Identifiant']}}/ajout_association">Crée une Association</a>
              <a href="{{url('/')}}/{{$personne['Identifiant']}}/ajout_event">Crée un Événement</a>
            </div>
        </div>
        <a href="{{url('/')}}"><li>Déconexion</li></a>
    </ul>
      <!--
    <ul>
        <a href="#event"><li>Événement</li></a>
        <a href="#asso"><li>Association</li></a>
        <a href="{{url('/')}}/{{$personne->Identifiant}}/Profil"><li>Mon Compte</li></a>
        <a href="{{url('/')}}"><li>Déconexion</li></a>
    </ul>-->
    @endif
</header>