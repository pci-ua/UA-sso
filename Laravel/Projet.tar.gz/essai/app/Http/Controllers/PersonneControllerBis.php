<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Personne;
use App\Models\Association;
use App\Models\Organisateur;
use App\Models\Participant;
use App\Models\Evenement;
use App\Models\Rejoindre_association;
use Illuminate\Support\Facades\DB;

//use App\Models\Demandeasso as Demande ;


class PersonneControllerBis extends Controller
{
    public function choix(){
        $personnes = Personne::all();

        return view('accueil', ['personnes' =>$personnes]);
    }
    public function infopers($identifiant){
        $personne = Personne::where('Identifiant', $identifiant)
        ->first();

return view('profil',['personne'=>$personne,'identifiant'=>$identifiant]);
    }


    public function connexion(){
        $personnes = Personne::all();
        return view('connexion',['personnes' =>$personnes]);
    }

    public function personne($identifiant){
        $pers=Personne::where('Identifiant','=', $identifiant)->get()[0];


        // Récupérer l'ID de la personne en utilisant l'identifiant
        $personneId = Personne::where('Identifiant', $identifiant)->value('id');

        // Récupérer les associations de la personne en utilisant l'ID de la personne
        $listeass = DB::table('Association_personne')
            ->join('Association', 'Association_personne.association_nom', '=', 'Association.Nom')
            ->where('Association_personne.personne_id', $personneId)
            ->pluck('Association.Nom')
            ->toArray();
        $evenement= Evenement::all();
        $assos = Association::all();
        //Pour affichage event organisateur en cours
            //rajouter des verifications si pas d'event
        //$soneventencours=Evenement::where('id','=', Organisateur::where('Id_pers','=',$pers['id'])->take(1)->get()[0]['Id_event'])->take(1)->get()[0];
        //dd($soneventencours);
        //Pour affichage event participant en cours
        $uneventencours['Nom']= 'Gala';

        //Pour les événements participant
        //$particiapnt=Evenement::where('id','=', Participant::where('Id_pers','=',$pers['id'])->take(1)->get()[0]['Id_event'])->take(1)->get()[0];
        //Pour l'affichage de ses evenements
        $mesevents=Organisateur::where('Id_pers','=',$pers['id'])->get();
        $sesevents=[];
        foreach($mesevents as $monevent){
            array_push($sesevents, Evenement::where('id','=', $monevent['Id_event'])->get()[0]);
        }
    return view('accueilPersonne', [ 'personne'=>$pers,'mesevents' => $sesevents,'listeass'=>$listeass, 'assos' => $assos, 'evenement' => $evenement ]);
    }
    public function gestion($identifiant, $id){
        $pers=Personne::where('Identifiant','=', $identifiant)->get()[0];
        $event=Evenement::where('id','=', $id)->get()[0];
        return view('gestion', [ 'personne'=>$pers, 'event'=> $event]);

    }

    public function ajoutpersonne($nom, $prenom,$filiere, $mail){
        $personne = New Personne;
        $chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $string = '';
        for($i=0; $i<10; $i++){
            $string .= $chars[rand(0, strlen($chars)-1)];
        }

        $personne->Identifiant= $string;

        $personne->Nom=$nom;
        $personne->Prenom=$prenom;
        $personne->Filiere=$filiere;
        $personne->mail=$mail;
        return($personne->save());
    }

    public function form( $identifiant, string $type){
        //$personne=Personne::where('Identifiant','=', $identifiant)->take(1)->get();
        //dd($personne[0]['Identifiant']);
        return view('Formulaire', ['type' => $type, 'personne'=>Personne::where('Identifiant','=', $identifiant)->get()[0]]);
    }

    public function ajout_asso($identifiant, $nom_asso,$desc){
        $association = New Association;
        $association->Nom=$nom_asso;
        $association->membre=Personne::where('Identifiant','=', $identifiant)->get()[0]['id'];
        //$association->description=$desc;
        return($association->save());
    }

    public function ajout_event($identifiant, $nom, $desc,$date,$max,$lieu,$Asso){
        $event = New Evenement;
        $event->Nom=$nom;
        $event->Description=$desc;
        $event->Date=$date;
        $event->Lieu=$lieu;
        $event->nb_max=$max;
        $event->Nom_assoc=$Asso;
        if($event->save()){
            $orga = New Organisateur;
            $orga->Id_event=Evenement::where('Nom','=', $nom)->get()[0]['id'];
            $orga->Id_pers=Personne::where('Identifiant','=', $identifiant)->get()[0]['id'];
            return($orga->save());

        }
        return null;
    }

    public function refuser($id, $Nom_asso){
        try {
            Rejoindre::where('Id_pers','=', $id, 2)->where('Nom_asso','=', $Nom_asso, 2)->delete();
            return true;
        } catch (\Throwable $th) {
            return false;
        }
    }

    public function accepter($id, $Nom_asso){
        if($this->refuser($id,$Nom_asso)){
            try {
                $membre = New Membre;
                $membre->Id_pers=$id;
                $membre->Id_Asso=$Nom_asso;
                if($membre->save())
                    return true;
                else
                    return false;
            } catch (\Throwable $th) {
                return false;
            }
        }
        else return false;
    }
    public function getstock($idevent){
        //$test=Evenement::where('id','=', $idevent)->get();
        return 'essaie';
    }
    public function getPersonInfoAjax($nom, $prenom)
    {
        $personnes = Personne::where('Nom', $nom)
                            ->where('Prenom', $prenom)
                            ->get();
        if ($personnes->isNotEmpty()) {
            $responseArray = [];
            foreach ($personnes as $personne) {
                $responseArray[] = [
                    'id' => $personne->id,
                    'identifiant'=>$personne->Identifiant,
                    'Nom' => $personne->Nom,
                    'Prenom' => $personne->Prenom,
                    'mail' => $personne->mail,
                    'Filiere'=>$personne->Filiere
                ];
            }
            return response()->json($responseArray);
        } else {
            return response()->json(['message' => 'Aucune personne trouvée avec le nom et le prénom fournis.'], 404);
        }
    }

    public function infouser($identifiant){
        $personne = Personne::where('Identifiant', $identifiant)
        ->first();
return $personne;
    }
    public function personneNom($identifiant){
        $personne = Personne::where('Identifiant', $identifiant)
        ->value('Nom');
return $personne;
    }
    public function modifinfo(Request $request, $identifier)
    {
        // Pour avoir l'id de la personne à partir de son identifiant
        $personneId = Personne::where('Identifiant', $identifier)->value('id');
        $pers = Personne::where('Identifiant', $identifier)->get()[0];


        // Get the form data
        $filiere = $request->input('filiere');
        $nom = $request->input('nom');
        $prenom = $request->input('prenom');
        $mail=$request->input('mail');

        $result = DB::table('Personne')->where('Identifiant', $identifier)->update([
            'Nom' => $nom,
            'Prenom' => $prenom,
            'mail' => $mail,
            'Filiere'=>$filiere
        ]);

if($result){
    $message="Les modifications ont été enregistrés";
}
else{
    $message="Une erreur est survenue...";
}
        // Et maintenant,on se redirige!
        return view('profil', ['personneid' => $personneId, 'identifiant' => $identifier, 'message' => $message, 'personne' => $pers]);
    }

  public function creationassoc(Request $request){
        // Récupérer les données du formulaire
        $nom = $request->input('nom');
        $description = $request->input('desc');

        // Vérifier si l'association existe déjà
        $existingAssoc = Association::where('Nom', $nom)->first();
        if ($existingAssoc) {
            // Rediriger avec un message d'erreur si l'association existe déjà
            return redirect()->route('creationassoc')->with('error', 'L\'association existe déjà. Veuillez choisir un autre nom.');
        }

        // Créer une nouvelle association
        $association = new Association;
        $association->Nom = $nom;
        $association->description = $description;
        $association->save();

        // Rediriger avec un message de succès
        return redirect()->route('creationassoc')->with('success', 'L\'association a été créée avec succès !');
    }


}

