<header>
    <?php if(isset($personne)): ?>
        <h1 id="NomUtilisateur"> <?php echo e($personne->Prenom); ?> <?php echo e($personne['Nom']); ?></h1>
        
    <?php else: ?>
        <h1> Projet Gestion Événement</h1>
    <?php endif; ?>
    <?php if(isset($personne)): ?>
    <ul>
        <?php if(isset($pageprincipale)): ?>
            <a href="#event"><li>Événement</li></a>
            <a href="#asso"><li>Association</li></a>
        <?php else: ?>
            <a href="<?php echo e(url('/')); ?>/<?php echo e($personne['Identifiant']); ?>#event"><li>Événement</li></a>
            <a href="<?php echo e(url('/')); ?>/<?php echo e($personne['Identifiant']); ?>#asso"><li>Association</li></a>
        <?php endif; ?>
        <a href="<?php echo e(url('/')); ?>/<?php echo e($personne->Identifiant); ?>/Profil"><li>Mon Compte</li></a>
        <div class="dropdown">
            <p>Action</p>
            <div class="dropdown-child">
              <a href="<?php echo e(url('/')); ?>/<?php echo e($personne['Identifiant']); ?>/inviterAssociation">Inviter</a>
              <a href="<?php echo e(url('/')); ?>/<?php echo e($personne['Identifiant']); ?>/ajout_association">Crée une Association</a>
              <a href="<?php echo e(url('/')); ?>/<?php echo e($personne['Identifiant']); ?>/ajout_event">Crée un Événement</a>
            </div>
        </div>
        <a href="<?php echo e(url('/')); ?>"><li>Déconexion</li></a>
    </ul>
      <!--
    <ul>
        <a href="#event"><li>Événement</li></a>
        <a href="#asso"><li>Association</li></a>
        <a href="<?php echo e(url('/')); ?>/<?php echo e($personne->Identifiant); ?>/Profil"><li>Mon Compte</li></a>
        <a href="<?php echo e(url('/')); ?>"><li>Déconexion</li></a>
    </ul>-->
    <?php endif; ?>
</header><?php /**PATH /opt/lampp/htdocs/essai/essai/resources/views/menu.blade.php ENDPATH**/ ?>