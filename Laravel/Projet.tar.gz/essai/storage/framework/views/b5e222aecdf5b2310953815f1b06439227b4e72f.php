<?php $__env->startSection('content'); ?>
    
    <h1>Asso Existantes</h1>

    <ul>
    <?php $__currentLoopData = $Assos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($asso['Nom']); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('gabari', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/essai/essai/resources/views/association.blade.php ENDPATH**/ ?>