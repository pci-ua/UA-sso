<header>
    <?php if(isset($personne)): ?>
        <h1> <?php echo e($personne->Prenom); ?> <?php echo e($personne['Nom']); ?></h1>
    <?php else: ?>
        <h1> Projet Gestion Événement</h1>
    <?php endif; ?>
    <ul>
        <a href="#event"><li>Événement</li></a>
        <a href="#asso"><li>Association</li></a>
        <a href="#asso"><li>Mon Compte</li></a>
    </ul>
</header><?php /**PATH /opt/lampp/htdocs/essai/essai/resources/views/menu.blade.php ENDPATH**/ ?>