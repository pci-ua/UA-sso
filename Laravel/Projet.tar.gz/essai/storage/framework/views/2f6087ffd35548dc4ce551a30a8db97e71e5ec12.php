<link rel="stylesheet" href="../style.css">
        

<?php $__env->startSection('content'); ?>
    
    <h1><?php echo e($message); ?></h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('gabari', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/essai/essai/resources/views/test.blade.php ENDPATH**/ ?>