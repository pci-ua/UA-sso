
@extends('gabari')

@section('content')
    
    <h1>{{$message}}</h1>
    @if (isset($personne))
        <a href="{{url('/')}}/{{$personne['Identifiant']}}"><button>Retour</button></a>
    @else
        <a href="{{url('/')}}"><button>Retour</button></a>
    @endif
@endsection