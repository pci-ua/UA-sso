
<section id="asso">
        <div>
            <h3>Rejoindre une Association:</h3>
        </div>
        <div v-for="asso in assos">
                <article>
                    <h5>{{asso.Nom}}</h5>
                    <button @click="rejoindre(asso)">Rejoindre</button>
                </article>
        </div>
        
    </section>

<script>
var Url=window.location.pathname;
var identifiant=Url.split('/')[1];

    const lesAssos= Vue.createApp({
        data(){
            return {
                assos: [],
                assosmembre: [],
                assoattente: [],
                id:[]
            }
        },
    methods: {
                actualiser() {
                    fetch('http://127.0.0.1:8000/api/getassos', {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                    }).then(response => response.json())
                    .then(data => this.assos = data)
                    .catch(error => console.log(error));

                    fetch('http://127.0.0.1:8000/api/getidpersonne?identifiant=' + identifiant, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                    }).then(response => response.json())
                    .then(data => {
                        this.id = [data];

                        fetch('http://127.0.0.1:8000/api/getassomembre?id=' + this.id, {
                        method: 'GET',
                        headers: {
                            'Content-Type': 'application/json'
                        }
                        }).then(response => response.json())
                        .then(data => {
                            this.assosmembre = data;

                            fetch('http://127.0.0.1:8000/api/getassoattente?id=' + this.id, {
                            method: 'GET',
                            headers: {
                                'Content-Type': 'application/json'
                            }
                            }).then(response => response.json())
                            .then(data => {
                                this.assoattente = data;
                                this.asso();
                            })
                            .catch(error => console.log(error));
                        })
                        .catch(error => console.log(error));
                    })
                    .catch(error => console.log(error));
                },
                asso(){
                    
                    this.assos = this.assos.filter(objet1 => !this.assosmembre.some(objet2 => objet2.association_nom === objet1.Nom));
                    this.assos = this.assos.filter(objet1 => !this.assoattente.some(objet2 => objet2.Nom_asso === objet1.Nom));
                    
                },
                rejoindre(asso){
                    link='http://127.0.0.1:8000/api/ajoutmembre?';
                    link+='id='+this.id;
                    link+='&nomasso='+asso.Nom;
                    console.log(link);
                    fetch(link, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                    }).then(response => response.json())
                    .then(data => console.log(data))
                    .catch(error => console.log(error))
                    this.actualiser();

                },
                
        }
    }).mount('#asso')
lesAssos.actualiser();
</script>