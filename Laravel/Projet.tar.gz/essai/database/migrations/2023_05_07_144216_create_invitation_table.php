<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateInvitationTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
            Schema::create('invitations', function (Blueprint $table) {
                $table->unsignedInteger('id_invitant');
                $table->unsignedInteger('id_invitee');
                $table->string('nom_assoc');
                $table->foreign('nom_assoc')->references('nom')->on('associations')->onDelete('cascade');
                $table->foreign('id_invitant')->references('id')->on('personnes')->onDelete('cascade');
                $table->foreign('id_invitee')->references('id')->on('personnes')->onDelete('cascade');
                $table->timestamps();
            });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
