
<section id="Participant" class="barregauche">
<h1>Gestion Participant</h1>
    <div v-for="part in parts">
        <h4>{{part.Nom}} {{part.Prenom}}</h4>
        <input type="button" value="retirer" @click="retirer(part)">
        <input type="button" value="Nommer organisateur" @click="orga(part)">
    </div>
</section>


<script>


var Url=window.location.pathname;
var id=Url.split('/')[2];

    const participants= Vue.createApp({
        data(){
            return {
                parts: []
            }
        },
        methods:{
                actualiser(){
                    fetch('http://127.0.0.1:8000/api/getParticpantsEvenement?event='+id, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                    }).then(response => response.json())
                    .then(data => this.parts=data)
                    .catch();

                },
                orga(part){
                    let link= 'http://127.0.0.1:8000/api/ajoutorganisateur?event='+id;
                    link+='&pers='+part.id;
                    fetch(link, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                    }).then(response => response.json())
                    .then(data => {
                        if(data==='déjà')
                            alert(part.Nom+' '+part.Prenom+' est déjà Organisateur')
                    })
                    .catch();

                },
                retirer(part){
                    let link= 'http://127.0.0.1:8000/api/supprparticipant?event='+id;
                    link+='&pers='+part.id;
                    fetch(link, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                    })

                    this.actualiser();
                },
                
            }

    }).mount('#Participant')


participants.actualiser();


</script>