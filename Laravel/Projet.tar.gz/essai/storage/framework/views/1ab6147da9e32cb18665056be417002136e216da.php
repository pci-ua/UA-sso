<!DOCTYPE html>
<html lang="fr">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
   <style>
    #mesdemande{
        width: 95%;
        background-color: white;
        margin-top: 20px;
        margin-bottom:20px;
        display: flex;
        flex-direction: column;
        align-items: center;
        padding: 10px;
    }
    #eventencours{
        width: 98%;
    }
    #contentstock{
        width: 80vw;
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    #contentstock div{
        width: 100%;
        display: flex;
        justify-content: center;

    }
    .monasso{
        padding: 20px;
    }
    .afficherevenement{
        display: flex;
        flex-direction: column;
    }
    .produit{
        display: flex;
        align-items: center;
    }
    .gestion{
        display: flex;
        width: 100%;
        justify-content: space-around;
    }
    .gestionstock{
        display: flex;
        flex-direction: column;
        align-items: center;
        padding-top: 25px;
    }
    .suppr{
        display: flex;
        padding-top: 100px;
        justify-content: center;
        align-content: center;
    }
    .zonenbr {
        width: 50px;
    }
    .barregauche{
        border-left: solid;
        height: 100%;
        width: 50%;
    }
    .espace {
        margin-top: 50px;
        padding-top: 10px;
    }
    .barre {
        border-top: solid;
        margin-top: 50px;
    }


    
    .dropdown-child {
        position: absolute;
        display: none;
        padding: 5px;
        background-color: #0097a1;
        border-radius: 0 0 20% 20% ; 
    }
    .dropdown-child a {
        color: black;
        text-decoration: none;
        display: block;
    }
    .dropdown:hover .dropdown-child {
        display: block;
    }
</style>

    <!--Pour la création du qrcode-->
    <script src="https://cdn.rawgit.com/davidshimjs/qrcodejs/gh-pages/qrcode.min.js"></script>

    <!--Pour vue.js-->
   <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
    <!--Pour les graphes -->
   <script src="https://cdn.jsdelivr.net/npm/chart.js@3.6.0"></script>
   <!--Pour les pdf-->
   <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.min.js"></script>

   <!--Pour connecter au serveur socket.io-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/socket.io/4.2.0/socket.io.js"></script>
   
    <title>Projet Asso gestion Event </title>
</head>

<body >
    <?php echo $__env->make('menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
    
</html><?php /**PATH /opt/lampp/htdocs/essai/essai/resources/views/gabari.blade.php ENDPATH**/ ?>