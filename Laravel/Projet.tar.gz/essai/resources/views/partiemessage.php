
<h4>notification</h4>
    <section id="contentmessage">
        <h5>Notification Actuelle: {{message}} </h5>
        <input ref="msg" type="text">
        <button @click="envoie">Envoyer</button>
    </section>

<script>
var Url=window.location.pathname;
var id=Url.split('/')[2];

    const messages= Vue.createApp({
        data(){
            return {
                message: ''
            }
        },
        methods:{
                actualiser(){
                    let link='http://127.0.0.1:8000/api/notifactuel?event='+id;
                    fetch(link, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                    })
                    .then(response => response.json())
                    .then(data => this.message=data)
                    .catch(error => {console.error('Une erreur s\'est produite:', error);
});

                    
                },
                envoie(){
                    let link='http://127.0.0.1:8000/api/notif?event='+id+'&msg='+this.$refs.msg.value;
                    fetch(link, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                    }).then(response => response.json())
                    .then(data => data)
                    .catch();
                    this.actualiser();
                }
            }
    }).mount('#contentmessage')
    messages.actualiser();

</script>

