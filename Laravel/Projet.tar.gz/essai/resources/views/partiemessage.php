
    <section id="contentmessage" >

    <h4>notification</h4>
        <h5>Notification Actuelle: {{message}} </h5>
        <input ref="msg" type="text">
        <button @click="envoie">Envoyer</button>
    </section>

<script>
var Url=window.location.pathname;
var id=Url.split('/')[2];

    const messages= Vue.createApp({
        data(){
            return {
                message: ''
            }
        },
        methods:{
                actualiser(){
                    let link='http://127.0.0.1:8000/api/notifactuel?event='+id;
                    fetch(link, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                    })
                    .then(response => response.json())
                    .then(data => this.message=data)
                    .catch(error => {console.error('Une erreur s\'est produite:', error);
                    });
                    
                },
                envoie(){
                    let link='http://127.0.0.1:8000/api/notif?event='+id+'&msg='+this.$refs.msg.value;
                    fetch(link, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                    }).then(response => response.json())
                    .then(data => data)
                    .catch();
                    send();
                    //this.actualiser();
                    
                }
            }
    }).mount('#contentmessage')
    messages.actualiser();

    
    var socket = io('localhost:3000');

    var send = function (){

            console.log(id);
            socket.emit('notificationevent', {id:id})
        }

    var receive = function(data){
        if(data.id==id){
            messages.actualiser();
        }
    }

    socket.on('notificationevent' , receive);


</script>

