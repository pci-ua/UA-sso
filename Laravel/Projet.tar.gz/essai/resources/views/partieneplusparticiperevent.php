
<div class="suppr">
    <button id="suppr">Ne plus participer</button>
</div>
<script>

let button = document.querySelector('#suppr');
var Url=window.location.pathname;
const id=Url.split('/')[3];
const identifiant=Url.split('/')[1];



button.addEventListener('click', () => {
   /*
    fetch('http://127.0.0.1:8000/api/getidpersonne?identifiant=', {
    method: 'GET',
    headers: {
        'Content-Type': 'application/json'
    }
    }).then(response => response.json())
    .then(data => {
        let link='http://127.0.0.1:8000/api/supprparticipant?event='+idevent+'&pers='data;
        fetch(link, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
        }).then(response => response.json())
        .then(data => {
            console.log('test avant');
            if(data){
                const host = window.location.host; // Hôte (par exemple, "www.example.com")
                const pathname = window.location.pathname; // Chemin d'accès (par exemple, "/ma-page.html")

                console.log('test apres');
                const newUrl ='http://'+host+'/'+pathname.split('/')[1];
                window.location.href=newUrl;
            }
        })
        .catch();
    })
    .catch();*/
    fetch('http://127.0.0.1:8000/api/getidpersonne?identifiant='+identifiant, {
  method: 'GET',
  headers: {
    'Content-Type': 'application/json'
  }
})
  .then(response => response.json())
  .then(data => {

    let link = 'http://127.0.0.1:8000/api/supprparticipant?event=' + id + '&pers=' + data;
    fetch(link, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json'
      }
    })
      .then(response => response.json())
      .then(data => {
        console.log('test avant');
        if (data) {
          const host = window.location.host; // Hôte (par exemple, "www.example.com")
          const pathname = window.location.pathname; // Chemin d'accès (par exemple, "/ma-page.html")

          console.log('test apres');
          const newUrl = 'http://' + host + '/' + pathname.split('/')[1];
          window.location.href = newUrl;
        }
      })
      .catch(error => {
        console.error('Une erreur s\'est produite lors de la suppression du participant:', error);
      });
  })
  .catch(error => {
    console.error('Une erreur s\'est produite lors de la récupération de l\'ID de la personne:', error);
  });

});
</script>