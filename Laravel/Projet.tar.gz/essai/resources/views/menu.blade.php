<header>
    @if (isset($personne))
        <h1 id="NomUtilisateur"> {{$personne->Prenom}} {{$personne['Nom']}}</h1>
        
    @else
        <h1> Projet Gestion Événement</h1>
    @endif
    @if (isset($personne))
    <ul>
        <a href="#event"><li>Événement</li></a>
        <a href="#asso"><li>Association</li></a>
        <a href="{{url('/')}}/{{$personne->Identifiant}}/Profil"><li>Mon Compte</li></a>
        <a href="{{url('/')}}"><li>Déconexion</li></a>
    </ul>
    @endif
</header>