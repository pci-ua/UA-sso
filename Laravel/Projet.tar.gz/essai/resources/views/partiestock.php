
    <section id="contentstock">
    <h2>Gestion Stock</h2>
        <div class="produit" v-for="prod in produits">
            <h4>{{prod.nom}}</h4>
            <p>: {{prod.quantite}}   |  </p>
            <input ref="quantite" class="zonenbr" type="number" name="nombreproduit" > 
            <input type="button" value="ajouter" @click="ajout(prod)">
            <input type="button" value="-" @click="moins(prod)">
            <input type="button" value="+" @click="plus(prod)">
        </div>
        <button @click="generateCSV()">Générer le fichier CSV</button>
    </section>
    <section id="creationproduit" class="espace">
        <h2>Création produit stock</h2>
        <label for="nomproduit">Produit:</label>
        <input type="text" name="nomproduit" v-model="nom">
        <label for="nomproduit">Quantité:</label>
        <input type="number" name="nombreproduit" v-model="quantite" >
        <input type="button" value="Creer Produit" @click="creer">
    </section>

<script>


var Url=window.location.pathname;
var id=Url.split('/')[2];

    const lesproduits= Vue.createApp({
        data(){
            return {
                quantite:0,
                produits: [
                ]
            }
        },
        methods:{
                actualiser(){
                    fetch('http://127.0.0.1:8000/api/stock?event='+id, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                    }).then(response => response.json())
                    .then(data => lesproduits.produits=data)
                    .catch(error => lesproduits.produits=[]);

                },
                ajoutdbb(quantite, nom){
                    let link='http://127.0.0.1:8000/api/modifierstock?event='+id+'&quantite='+quantite+'&nom='+nom;
                    fetch(link, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                    }).then(response => response.json())
                    .then(data => data)
                    .catch();
                    this.actualiser();
                },
                ajout(prod){

                    index=this.produits.findIndex(produit=> produit.nom === prod.nom );
                    ajout=parseInt(this.$refs.quantite[index].value);
                    
                    if(Number.isInteger(ajout)){
                        if(this.produits[index].quantite+ajout>=0)
                            this.ajoutdbb(ajout, prod.nom);
                    }
                },
                plus(prod){
                    /*index=this.produits.findIndex(produit=> produit.nom === prod.nom )
                    this.produits[index].quantite++*/
                    this.ajoutdbb(1,prod.nom);
                },
                moins(prod){
                    index=this.produits.findIndex(produit=> produit.nom === prod.nom )
                    //this.produits[index].quantite--
                    if((this.produits[index].quantite-1 )>=0)
                        this.ajoutdbb(-1,prod.nom);
                },
                generateCSV(){

                    let link='http://127.0.0.1:8000/api/consototal?event='+id;
                    fetch(link, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                    }).then(response => response.json())
                    .then(data => {
                        // Données à exporter en CSV
                        var dataTab = [['Nom Produit', 'Quantité Vendu']];
                        
                        //On mets les données dans le bon format
                        data.forEach((element) => {
                            dataTab.push([element.NomProduit,element.total]);
                        });
                        // Convertir les données en format CSV
                        const csvContent = dataTab.map(row => row.join(',')).join('\n');

                        // Créer un objet Blob à partir du contenu CSV
                        const blob = new Blob([csvContent], { type: 'text/csv' });

                        // Créer un lien de téléchargement
                        const link = document.createElement('a');
                        link.href = URL.createObjectURL(blob);
                        link.download = 'TotalConsommation.csv';
                        link.click();

                        // Nettoyer l'URL de l'objet Blob
                        URL.revokeObjectURL(link.href);
                    
                    })
                    .catch();
                    
                    
                    }
            }

    }).mount('#contentstock')

    const creationproduit= Vue.createApp({
        data(){
            return {
                message: 'Test',
                nom:'Produit',
                quantite:0
            }
        },
        methods:{
            creer(){
                let link='http://127.0.0.1:8000/api/creerstock?event='+id+'&quantite='+this.quantite+'&nom='+this.nom;
                fetch(link, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
                }).then(response => response.json())
                .then(data => data)
                .catch();

            lesproduits.actualiser();

            }
        }
    }).mount('#creationproduit')

lesproduits.actualiser();
</script>