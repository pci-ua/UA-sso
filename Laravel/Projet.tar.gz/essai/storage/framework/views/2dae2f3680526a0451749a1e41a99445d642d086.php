<?php $__env->startSection('content'); ?>
    
    <h1>Vous devez être connecter</h1>

    <label>Qui etes-vous?</label>
    <ul>
    <?php $__currentLoopData = $personnes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a href="http://127.0.0.1:8000/<?php echo e($personne['Identifiant']); ?>"><?php echo e($personne['Nom']); ?> <?php echo e($personne['Prenom']); ?></a></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <section class="ajout">
    <h3>Ajout</h3>
    <form action="<?php echo e(url('/')); ?>/ajout_personne" method="post">
        <?php echo e(csrf_field()); ?>

        <label for="nom">Nom :</label>
        <input type="text" id="nom" name="nom">

        <label for="prenom">Prenom :</label>
        <input type="text" id="prenom" name="prenom">

        <label for="filiere">Filière :</label>
        <input type="text" id="filiere" name="filiere">

        <label for="mail">Mail :</label>
        <input type="email" id="mail" name="mail">

        <button type="submit">Envoyer le message</button>

    </form>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('gabari', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/essai/essai/resources/views/connexion.blade.php ENDPATH**/ ?>