<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

use App\Models\Evenement as Evenement ;
use App\Models\Participant as Participant ;   
use App\Models\Personne as Personne ; 
use App\Models\Association as Association ;
use App\Models\Organisateur as Organisateur ;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});


Route::post('/{identifiant}/inviterAssociation', function($identifiant){
    //creer la base
    /*DB::table('invitations')->insert([
        'id_invitee' => $id,
        'id_invitant' => $personneId,
        'nom_assoc' => $asso
    ]);*/
    return true;
});

//Personne
Route::get('getidpersonne', function(){
    return json_encode(Personne::where('Identifiant','=', $_GET['identifiant'])->get()[0]['id']);
});


//Gestion stock
Route::get('supprstock', function(){
    $stock=Evenement::where('id','=', $_GET['event'])->get()['0'];
    if($stock->stock){
        // si un stock
        $stock->stock=[];
        
        $stock->save();
        return Evenement::where('id','=', $_GET['event'])->get()['0'];
    }
    else {
        //Pas de stock
    }
});

Route::get('creerstock', function(){
    $stock=Evenement::where('id','=', $_GET['event'])->get()['0'];
    $stockArray=[];
    if($stock->stock){
        //un stock
        $stockArray = json_decode($stock->stock);

        //test si le produit n'existe pas déjà
        $test=false;
        foreach($stockArray as $produit){
            if($produit->nom ==$_GET['nom'])
                $test=true;
        }

        if(!$test){
            array_push($stockArray, ["nom"=>$_GET['nom'], "quantite"=> $_GET['quantite'], "alcool"=>$_GET['alcool'], "prix"=>$_GET['prix'] ]);
            //$stockArray=["nom"=>$_GET['nom'], "quantite"=> $_GET['quantite'], "alcool"=>$_GET['alcool'], "prix"=>$_GET['prix'] ];
            $stock->stock=json_encode($stockArray);
            
            $stock->save();
            return Evenement::where('id','=', $_GET['event'])->get()['0'];
        }
        else {
            return json_encode('déjà present');
        }
    }
    else {
        //Pas de stock
        $stock->stock=json_encode([["nom"=>$_GET['nom'], "quantite"=> $_GET['quantite'],"prix"=> $_GET['prix'], "alcool"=> $_GET['alcool']]]);
        $stock->save();
        return Evenement::where('id','=', $_GET['event'])->get()['0'];
    }
});
Route::get('modifierstock', function(){
    $stock=Evenement::where('id','=', $_GET['event'])->get()['0'];
    $stockArray= json_decode($stock->stock);
    foreach($stockArray as $produit){
        if($produit->nom==$_GET['nom']){
            $produit->quantite+=$_GET['quantite'];
        }
    }
    $stock->stock=json_encode($stockArray);
    $stock->save();
    //si diminution alors on sauvegarde la consommation
    if($_GET['quantite']<0){
        date_default_timezone_set('Europe/Paris');
        $date = date('h:i:s');
        for ($i=0; $i > $_GET['quantite'] ; $i--) { 
            //on ajoute le nombre de fois où le produit est enlevé
            DB::table('HistoriqueConso')->insert([
                'IdEvent' => $_GET['event'],
                'NomProduit' => $_GET['nom'],
                'alcool' => $_GET['alcool'],
                'prix' => $_GET['prix'],
                'Horaire' => $date
            ]);
        }
    }
    return Evenement::where('id','=', $_GET['event'])->get()['0'];
});
Route::get('supprproduit', function(){
    $stock=Evenement::where('id','=', $_GET['event'])->get()['0'];
    $stockArray= json_decode($stock->stock);
    $index=-1;
    $newtab=[];
    foreach($stockArray as $produit){
        if($produit->nom!=$_GET['nom']){
            array_push($newtab,$produit);
        }
    }
    $stock->stock=json_encode($newtab);
    $stock->save();
    
    return Evenement::where('id','=', $_GET['event'])->get()['0'];
});

Route::get('stock', function(){
    $test=Evenement::where('id','=', $_GET['event'])->get()['0']['stock'];
    return $test;
});


Route::get('conso', function(){
    $test=DB::table('HistoriqueConso')->where('IdEvent', $_GET['event'])->get();
    return $test;
});


Route::get('consototal', function(){
    $test=DB::table('HistoriqueConso')->where('IdEvent', $_GET['event'])->get();
    //$resultats = DB::table('HistoriqueConso')->where('IdEvent', $_GET['event'])->select('NomProduit', DB::raw('COUNT(*) as total'))->groupBy('NomProduit')->get();
    $resultats = DB::table('HistoriqueConso')
    ->where('IdEvent', $_GET['event'])
    ->select('NomProduit', DB::raw('prix'), 'alcool', DB::raw('COUNT(*) as total'))
    ->groupBy('NomProduit', 'prix', 'alcool')
    ->get();

    return $resultats;
});

//Gestion Notification
Route::get('notifactuel', function(){
    return json_encode(Evenement::where('id','=', $_GET['event'])->get()['0']['Notification']);
});

Route::get('notif', function(){
    $stock=Evenement::where('id','=', $_GET['event'])->get()['0'];
    $stock->Notification=$_GET['msg'];
    $stock->save();
    return Evenement::where('id','=', $_GET['event'])->get()['0'];
});


//Evenement
Route::get('evenements', function(){
    return Evenement::all();
});

Route::get('supprevenement', function(){
    
    Participant::where('Id_event','=',$_GET['event'])->delete();
    Organisateur::where('Id_event','=',$_GET['event'])->delete();
    Evenement::where('id','=',$_GET['event'])->delete();
    DB::table('HistoriqueConso')->where('IdEvent', $_GET['event'])->delete();
    return json_encode(true);
});


Route::get('evenementsPers', function(){
    $tab=[];
    if(isset(Participant::where('Id_pers','=', $_GET['id'])->get()['0'])){
        $events=Participant::where('Id_pers','=', $_GET['id'])->get();
        foreach($events as $event){
            array_push($tab,Evenement::where('id','=', $event->Id_event)->get()['0']);
        }
    }
    return $tab;
});

Route::get('getParticpantsEvenement', function(){
    $tab=[];
    if(isset(Participant::where('Id_event','=', $_GET['event'])->get()[0])){
        $parts=Participant::where('Id_event','=', $_GET['event'])->get();
        foreach($parts as $part){
            array_push($tab,Personne::where('id','=', $part->Id_pers)->get()[0]);
        }
    }
    return $tab;
});

Route::get('supprparticipant', function(){
    
    return Participant::where('Id_pers','=', $_GET['pers'])->where('Id_event','=',$_GET['event'])->delete();

});

Route::get('ajoutorganisateur', function(){
    if(!isset(Organisateur::where('Id_pers','=', $_GET['pers'])->where('Id_event','=',$_GET['event'])->get()[0]) ){
        return Organisateur::insert([
        'Id_pers' => $_GET['pers'],
        'Id_event' => $_GET['event']
        ]);
    }else {
        return json_encode('déjà');
    }
});


Route::get('ajoutparticipant', function(){
    
    $event= json_decode($_GET['event']);
    
    if(!isset(Participant::where('Id_pers','=', $_GET['id'])->where('Id_event','=',$event->id)->get()['0'])){
        $participant= New Participant;
        $participant->Id_pers=$_GET['id'];
        $participant->Id_event=$event->id;

        $participant->Consommation=0;
        $participant->Heure_arrive= '12/12/12';
        $participant->Heure_depart='12/12/12';

        $participant->save();
        return $participant;
    }
    else return json_encode('déjà');
});


//Gestion rejoindre Association


Route::get('ajoutmembre', function(){
    
    return    DB::table('Rejoindre_association')->insert([
        'Id_pers' => $_GET['id'],
        'Nom_asso' => $_GET['nomasso']
    ]);

});


Route::get('getassos', function(){
    
    return Association::all();

});

Route::get('getassomembre', function(){
    
    $membre = DB::table('association_personnes')->where('personne_id','=', $_GET['id'])->get();
    return $membre;

});


Route::get('getassoattente', function(){
    $demande = DB::table('Rejoindre_association')->where('Id_pers','=', $_GET['id'])->get();
    return $demande;
});


//Gestion invitation


Route::get('getinvitationasso', function(){
    
    return   DB::table('invitations')->where('id_invitee','=', $_GET['id'])->get();

});



Route::get('refuserinvitasso', function(){
    //On supprimer de la table demande sans l'ajouter dans membre
    $inv = json_decode($_GET['invit']);
    
    return DB::table('invitations')->where('id_invitee', $inv->id_invitee)->where('nom_assoc', $inv->nom_assoc )->delete();
});


Route::get('accepterinvitasso', function(){
    //On supprimer de la table invit et on l'ajouter dans membre de l'asso
    $inv = json_decode($_GET['invit']);
    
    DB::table('association_personnes')->insert([
        'personne_id' => $inv->id_invitee,
        'association_nom' => $inv->nom_assoc
    ]);

    DB::table('invitations')->where('id_invitee', $inv->id_invitee)->where('nom_assoc', $inv->nom_assoc )->delete();

});



// à finir


Route::get('getdemandeasso', function(){
    //recup tout les demandes en fonction des asso de la personne
    $id=Personne::where('Identifiant','=', $_GET['identifiant'])->get()[0]->id;
    
    $tab=[];
    if(isset(DB::table('association_personnes')->where('personne_id', $id)->get()[0])){
        
        $assos=DB::table('association_personnes')->where('personne_id', $id)->get();
    
        foreach($assos as $asso){
            if(isset(DB::table('Rejoindre_association')->where('Nom_asso', $asso->association_nom)->get()[0])){
                $invits=DB::table('Rejoindre_association')->where('Nom_asso', $asso->association_nom)->get();
                foreach($invits as $invit){
                    $invit->pers=Personne::where('id','=', $invit->Id_pers)->get()[0];
                    array_push($tab,$invit);
                }
            }
        }
        $comparerObjets = function ($objet1, $objet2) {
            return ($objet1->Id_pers === $objet2->Id_pers && $objet1->Nom_asso === $objet2->Nom_asso);
        };
        // Supprimer les doublons en utilisant array_unique() avec la fonction de rappel
        $tab = array_unique($tab, SORT_REGULAR);
        
    }
    return $tab;

});



Route::get('refuserdemandeasso', function(){
    //On supprimer de la table demande sans l'ajouter dans membre
    $dem = json_decode($_GET['dem']);
    
    return DB::table('Rejoindre_association')->where('id_pers', $dem->Id_pers)->where('Nom_asso', $dem->Nom_asso )->delete();
});


Route::get('accepterdemandeasso', function(){
    //On supprimer de la table demande et on l'ajouter dans membre de l'asso
    $dem = json_decode($_GET['dem']);
    
    DB::table('association_personnes')->insert([
        'personne_id' => $dem->Id_pers,
        'association_nom' => $dem->Nom_asso
    ]);


    return DB::table('Rejoindre_association')->where('id_pers', $dem->Id_pers)->where('Nom_asso', $dem->Nom_asso )->delete();
});