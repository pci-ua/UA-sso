<?php $__env->startSection('content'); ?>
<?php if($type =='asso'): ?>
    <h3>Créer Association</h3>
    <form action="<?php echo e(url('/')); ?>/<?php echo e($personne['Identifiant']); ?>/ajout_association" method="post">
        <?php echo e(csrf_field()); ?>

        <label for="nom">Nom :</label>
        <input type="text" name="nom">

        <label for="prenom">Description:</label>
        <input type="text" name="description">

        <button type="submit">Créer</button>
    
    </form>
<?php else: ?>
    <h3>Créer Événement</h3>
    <form action="<?php echo e(url('/')); ?>/<?php echo e($personne['Identifiant']); ?>/ajout_event" method="post">
        <?php echo e(csrf_field()); ?>

        <label for="nom">Nom :</label>
        <input type="text"name="nom">

        <label for="description">Description :</label>
        <input type="text" name="description">

        <label for="date">Date :</label>
        <input type="date" name="date">

        <label for="max">Nombre maximum :</label>
        <input type="number" name="max">

        <label for="lieu">Lieu</label>
        <input type="text" name="lieu" >

        <label for="Asso">Association</label>
        <input type="text" name="Asso">

        <button type="submit">Envoyer le message</button>
    </form>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('gabari', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/essai/essai/resources/views/Formulaire.blade.php ENDPATH**/ ?>