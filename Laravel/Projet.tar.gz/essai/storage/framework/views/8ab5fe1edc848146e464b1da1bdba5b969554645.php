<footer>
    <div>
        <h4>Création</h4> 
        <?php if(isset($personne)): ?>   
        <a href="<?php echo e(url('/')); ?>/<?php echo e($personne['Identifiant']); ?>/ajout_association">Crée une Association</a>
        <a href="<?php echo e(url('/')); ?>/<?php echo e($personne['Identifiant']); ?>/ajout_event">Crée un Événement</a>
        <a href="<?php echo e(url('/')); ?>/<?php echo e($personne['Identifiant']); ?>/inviterAssociation">Inviter dans une Association</a>
        <?php else: ?>
        <a href="<?php echo e(url('/')); ?>/ajout_association">Crée une Association</a>
        <a href="<?php echo e(url('/')); ?>/ajout_event">Crée un Événement</a>
        <?php endif; ?>    
    </div>

    <a href="https://projetcohesion.info/contacts/"><h4>Contact</h4></a>
    <a href="https://projetcohesion.info/a-propos/#bureau"><h4>À propros</h4></a>
</footer>
<?php /**PATH /opt/lampp/htdocs/essai/essai/resources/views/footer.blade.php ENDPATH**/ ?>