<script>
    var Url=window.location.pathname;
    const Nomasso=Url.split('/')[3];
    const Utilisateur=document.getElementById('NomUtilisateur').textContent;

    var socket = io('localhost:3000');
/*
    var send = function (){
        var text = document.getElementById('m').value;
        socket.emit('chat message', text)
    }

    var receive = function(msg){
        var li = document.createElement('li');
        li.innerText = msg;
        document.getElementById('messages').appendChild(li);
    }
    socket.on('chat message', receive);
*/

var sendchat = function (){

        var text = document.getElementById('m').value;
        var name = Utilisateur;
        socket.emit('chatevent', {id:id ,nom:name,msg:text})

        // Sélection de l'élément input
        document.getElementById("m").value="";

    }

var receivechat = function(data){
    if(data.id==id){
        if(data.nom==Utilisateur){
            // Création de la div
            var newDiv = document.createElement("div");

            // Ajout de contenu à la div
            // Création de l'élément <h5>
var heading = document.createElement("h5");
heading.textContent = data.nom+':';

// Création de l'élément <p>
var paragraph = document.createElement("p");
paragraph.textContent = data.msg;

// Ajout des éléments <h5> et <p> à la div
newDiv.appendChild(heading);
newDiv.appendChild(paragraph);

            // Ajout de classes à la div (optionnel)
            newDiv.classList.add("droite");

            // Ajout d'attributs à la div (optionnel)
            newDiv.setAttribute("id", "maDiv");

            // Ajout de la div au document
            document.getElementById('messages').appendChild(newDiv);
        }else {

            // Création de la div
            var newDiv = document.createElement("div");

            // Création de l'élément <h5>
var heading = document.createElement("h5");
heading.textContent = data.nom+':';

// Création de l'élément <p>
var paragraph = document.createElement("p");
paragraph.textContent = data.msg;

// Ajout des éléments <h5> et <p> à la div
newDiv.appendChild(heading);
newDiv.appendChild(paragraph);

            // Ajout de classes à la div (optionnel)
            newDiv.classList.add("gauche");

            // Ajout d'attributs à la div (optionnel)
            newDiv.setAttribute("id", "maDiv");

            // Ajout de la div au document
            document.getElementById('messages').appendChild(newDiv);
        }
    }
}

    socket.on('chatevent' , receivechat);

    window.addEventListener('load', function() {
        var chatContainer = document.getElementById('containe');
        var chatToggle = document.getElementById('supprchat');
        var button = document.getElementById('chat-toggle');
        chatToggle.addEventListener('click', function() {
            chatContainer.classList.toggle('closed');
            button.classList.remove('closed');
        });
        button.addEventListener('click', function() {
            chatContainer.classList.remove('closed');
            button.classList.toggle('closed');
        });
    });

</script>
<style>
    #tchat{
        display: flex;
        flex-direction: column;
        align-items: center;
        width: 100%;
        height: 40%;
    }
    #tchat-inner {
  overflow: auto;
  max-height: 600px; /* Définir une hauteur maximale pour l'élément */
}
    #containe {
        margin-top:50px;
        width: 400px;
        height: 400px;
        overflow: hidden;
        display: flex;
        background-color:white;
        flex-direction: column;
        justify-content: flex-end;
        padding:10px;
    }
    #containe ul {
        overflow-y: scroll;
        scrollbar-color: grey white;
        scrollbar-width: thin;

    }
    #sectionmsg {
        width: 100%;
        display: flex;
        flex-direction: row;
    }
    #sectionmsg input {
        width: 80%;
    }

    #sectionmsg button {
        width: 20%;
    }
    #messages {
    display: flex;
    display: block;
    justify-content: space-between;
    list-style: none;
    padding: 0;
    overflow: scroll;
    width: 100%;
    height: 95%;
    }

    .gauche {
        width: 100%;
        display: flex;
        flex-direction: column;

        align-items: flex-start;
    }

    .droite {
        width: 100%;
        display: flex;
        flex-direction: column;
        align-items: flex-end;
    }

</style>

<section id="tchat">
    <div id="containe">
        <div id="messages">

        </div>
        <div id="sectionmsg" ><input id="m" /> <button onclick="sendchat()">envoyer</button></div>
    </div>
</section>
