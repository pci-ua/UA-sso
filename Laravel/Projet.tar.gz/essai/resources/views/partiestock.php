    <section id="contentstock">
    <h3>Gestion Stock</h3>
        <h4 style="text-decoration: underline; margin-bottom:5px;">Boisson Alcoolisée</h4>
        <div class="produit" v-for="prod in produits" >
            <div class="produit" v-if="prod.alcool=='alcool'" style="width:100%; background-color:white;">
            <h4>{{prod.nom}}</h4>
            <p>: {{prod.quantite}}   |  </p>
            <input :ref="prod.nom" class="zonenbr" type="number" name="nombreproduit" > 
            <input type="button" value="ajouter" @click="ajout(prod)">
            <input type="button" value="-" @click="moins(prod)">
            <input type="button" value="+" @click="plus(prod)">
            <input style="margin-left:50px;margin-right:50px;" type="button" value="retirer" @click="supprproduit(prod)">
            
            <p> {{prod.prix}} €</p>
            </div>
        </div>


        <h4 style="margin-top:10px;text-decoration: underline; margin-bottom:5px;" >Boisson sans Alcool</h4>
        <div class="produit" v-for="prod in produits" >
            <div class="produit" v-if="prod.alcool=='sans'" style="width:100%; background-color:white;">
            <h4>{{prod.nom}}</h4>
            <p>: {{prod.quantite}}   |  </p>
            <input :ref="prod.nom" class="zonenbr" type="number" name="nombreproduit" > 
            <input type="button" value="ajouter" @click="ajout(prod)">
            <input type="button" value="-" @click="moins(prod)">
            <input type="button" value="+" @click="plus(prod)">
            <input style="margin-left:50px;margin-right:50px;" type="button" value="retirer" @click="supprproduit(prod)">
            
            <p> {{prod.prix}} €</p>
            </div>
        </div>

        <div style="margin-top:25px; border-top: solid;">
            <button @click="generateCSV()">Générer fichier CSV</button>
            <button @click="supprhisto()">Supprimer l'historique des consommation</button>
        </div>  

        <div style="margin-top: 50px; weidth:100%; display:flex; flex-direction : column; justify-content: center; align-items: center; background-color:white;">
            <h4 style="text-decoration: underline;" >Historique de consommation</h4>
            <div style="width:35%; max-width:300px; height:20%; display:flex; justify-constent:center;"><canvas ref="barChart"></canvas></div>
            <div style="display:flex;">
            <div style="width:40%; max-width:500px;"><canvas ref="pieChart"></canvas></div>
            <div style="width:40%; max-width:500px;"><canvas ref="pieChart2"></canvas></div>
            </div>
        </div>
    </section>
    <section id="creationproduit" class="espace">
        <h2>Création produit stock</h2>
        <label for="nomproduit">Produit:</label>
        <input type="text" name="nomproduit" v-model="nom">
        <label for="nomproduit">Quantité:</label>
        <input type="number" name="nombreproduit" v-model="quantite" >
        <label for="nomproduit">Prix:</label>
        <input type="number" name="prix" v-model="prix" >
        <select v-model="alcool">
            <option value="alcool">Avec Alcool</option>
            <option value="sans">Sans Alcool</option>
        </select>
        <input type="button" value="Creer Produit" @click="creer">
    </section>

<script>


var Url=window.location.pathname;
var id=Url.split('/')[2];

    const lesproduits= Vue.createApp({
        mounted() {
        
        this.actualiser();
        this.renderChart();
        },
        data(){
            return {
                quantite:0,
                produits: [],
                Historique: [],
                Chart1:[],
                Chart2:[],
                Chart3:[]
            }
        },
        methods:{
                actualiser(){
                    fetch('http://127.0.0.1:8000/api/stock?event='+id, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                    }).then(response => response.json())
                    .then(data => lesproduits.produits=data)
                    .catch(error => lesproduits.produits=[]);


                },
                ajoutdbb(quantite, prod){
                    let link='http://127.0.0.1:8000/api/modifierstock?event='+id+'&quantite='+quantite+'&nom='+prod.nom+'&alcool='+prod.alcool+'&prix='+prod.prix;
                    fetch(link, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                    }).then(response => response.json())
                    .then(data => data)
                    .catch();
                    this.actualiser();
                    //this.update();
                    
                    //notifié qu'on a changé le stock au socket
                    sendstock();
                },
                ajout(prod){

                    //index=this.produits.findIndex(produit=> produit.nom === prod.nom );
                    //ajout=parseInt(this.$refs.quantite[index].value);
                    //this.$refs.quantite[index].value
                    string=prod.nom;
                    //console.log(string);
                    //console.log(this.$refs[string][0].value);
                    ajout= +this.$refs[string][0].value;
                    if(Number.isInteger(ajout)){
                        //console.log('ici');
                        if(prod.quantite+ajout>=0)
                            this.ajoutdbb(ajout, prod);
                    }
                },
                plus(prod){
                    /*index=this.produits.findIndex(produit=> produit.nom === prod.nom )
                    this.produits[index].quantite++*/
                    this.ajoutdbb(1,prod);
                },
                moins(prod){
                    index=this.produits.findIndex(produit=> produit.nom === prod.nom )
                    //this.produits[index].quantite--
                    if((this.produits[index].quantite-1 )>=0)
                        this.ajoutdbb(-1,prod);
                },
                supprproduit(prod){
                    let link='http://127.0.0.1:8000/api/supprproduit?event='+id+'&nom='+prod.nom;
                    fetch(link, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                    }).then(response => response.json())
                    .then(data => data)
                    .catch();
                    this.actualiser();
                
                },
                generateCSV(){

                    let link='http://127.0.0.1:8000/api/consototal?event='+id;
                    fetch(link, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                    }).then(response => response.json())
                    .then(data => {
                        // Données à exporter en CSV
                        var dataTab = [['Nom Produit', 'Quantité Vendu','Prix Unitaire', 'Prix Total', '','Total Vente','Total']];
                        
                        //On mets les données dans le bon format
                        var totalsoiree=0;
                        var totalalcool=0;
                        var totalsans=0;
                        var quantitealcool=0;
                        var quantitesans=0;
                        console.log(data);
                        data.forEach((element) => {
                            if(element.alcool ==='alcool'){
                                totalalcool+=(element.total*element.prix);
                                quantitealcool+=element.total;
                                console.log(element.total);
                            }else{
                                totalsans+=(element.total*element.prix);
                                quantitesans+=element.total;
                            }
                            
                            totalsoiree+=(element.total*element.prix);
                            dataTab.push([element.NomProduit,element.total, element.prix, element.total*element.prix]);
                        });
                        dataTab[1][5]=quantitealcool+quantitesans;
                        dataTab[1][6]=totalsoiree;
                        console.log(dataTab);
                        if(dataTab.length >6){
                            dataTab[3][5]='Type:'; dataTab[3][6]='Nombre de Ventes'; dataTab[3][7]='Total';
                            dataTab[4][5]='Alcool:'; dataTab[4][6]=quantitealcool; dataTab[4][7]=totalalcool;
                            dataTab[5][5]='Sans Alcool:'; dataTab[5][6]=quantitesans; dataTab[5][7]=totalsans;
                        }else{
                            if(data.lenght !=0){
                                for (let index = dataTab.length; index < 6; index++) {
                                    dataTab.push(['', '','', '', '','']);
                                }
                                dataTab[3][5]='Type:'; dataTab[3][6]='Nombre de Ventes'; dataTab[3][7]='Total';
                                dataTab[4][5]='Alcool:'; dataTab[4][6]=quantitealcool; dataTab[4][7]=totalalcool;
                                dataTab[5][5]='Sans Alcool:'; dataTab[5][6]=quantitesans; dataTab[5][7]=totalsans;
                            }
                        }

                        // Convertir les données en format CSV
                        const csvContent = dataTab.map(row => row.join(',')).join('\n');

                        // Créer un objet Blob à partir du contenu CSV
                        const blob = new Blob([csvContent], { type: 'text/csv' });

                        // Créer un lien de téléchargement
                        const link = document.createElement('a');
                        link.href = URL.createObjectURL(blob);
                        link.download = 'Evenement_Consommation.csv';
                        link.click();

                        // Nettoyer l'URL de l'objet Blob
                        URL.revokeObjectURL(link.href);
                    
                    })
                    .catch();
                    
                    
                    },
                    renderChart() {


                        let link='http://127.0.0.1:8000/api/consototal?event='+id;
                        fetch(link, {
                        method: 'GET',
                        headers: {
                            'Content-Type': 'application/json'
                        }
                        }).then(response => response.json())
                        .then(histo => {
                            this.Historique=histo;
                        
                            const canvas = this.$refs.barChart;
                            const ctx = canvas.getContext('2d');
                            
                            let alcool = 0;
                            let sans = 0;
                            let tabproduitsans = [];
                            let tabquantitesans = [];

                            let tabproduitavec = [];
                            let tabquantiteavec = [];

                            let couleur = ['#00c3af','#006ec5','#3a48bb','#7420b1'];//'#d3288f'
                            histo.forEach((element) => {
                                if(element.alcool=='alcool'){
                                    alcool+=element.total;      
                                    tabproduitavec.push(element.NomProduit);
                                    tabquantiteavec.push(element.total);  
                                }else {
                                    sans+=element.total;
                                    tabproduitsans.push(element.NomProduit);
                                    tabquantitesans.push(element.total);
                                }
                            });
                            data = {
                                labels: ['Alcool', 'Sans alcool'],
                                datasets: [
                                {
                                    label: 'Type de consommation',
                                    data: [alcool,sans],
                                    backgroundColor: ['#006ec5','#7420b1']
                                }
                                ]
                            };

                            this.Chart1=new Chart(ctx, {
                                type: 'pie',
                                data: data,
                                options: {}
                            });

                            const canvas2 = this.$refs.pieChart;
                            const ctx2 = canvas2.getContext('2d');

                            const data2 = {
                                labels: tabproduitsans,
                                datasets: [
                                {
                                    label: 'sans Alcool',
                                    data: tabquantitesans,
                                    backgroundColor: couleur
                                }
                                ]
                            };

                            this.Chart2=new Chart(ctx2, {
                                type: 'bar',
                                data: data2,
                                options: {}
                            });


                            const canvas3 = this.$refs.pieChart2;
                            const ctx3 = canvas3.getContext('2d');

                            const data3 = {
                                labels: tabproduitavec,
                                datasets: [
                                {
                                    label: 'Alcoolisée',
                                    data: tabquantiteavec,
                                    backgroundColor: couleur
                                }
                                ]
                            };

                            this.Chart3=new Chart(ctx3, {
                                type: 'bar',
                                data: data3,
                                options: {}
                            });
                        })
                        .catch();
                    
                    },
                    update() {

                        let link='http://127.0.0.1:8000/api/consototal?event='+id;
                        fetch(link, {
                        method: 'GET',
                        headers: {
                            'Content-Type': 'application/json'
                        }
                        }).then(response => response.json())
                        .then(histo => {
                            this.Historique=histo;
                        
                            let alcool = 0;
                            let sans = 0;
                            let tabproduitsans = [];
                            let tabquantitesans = [];

                            let tabproduitavec = [];
                            let tabquantiteavec = [];

                            let couleur = ['#00c3af','#006ec5','#3a48bb','#7420b1'];//'#d3288f'
                            histo.forEach((element) => {
                                if(element.alcool=='alcool'){
                                    alcool+=element.total;      
                                    tabproduitavec.push(element.NomProduit);
                                    tabquantiteavec.push(element.total);  
                                }else {
                                    sans+=element.total;
                                    tabproduitsans.push(element.NomProduit);
                                    tabquantitesans.push(element.total);
                                }
                            });


                            // Détruire l'ancienne instance du graphique
                            this.Chart1.destroy();

                            // Mettre à jour les données du graphique
                            this.Chart1.data.datasets[0].data = [alcool,sans];

                            // Créer une nouvelle instance du graphique avec les données mises à jour
                            const canvas = this.$refs.barChart;
                            const ctx = canvas.getContext('2d');
                            
                            this.Chart1 = new Chart(ctx, {
                            type: 'pie',
                            data: this.Chart1.data,
                            options: {}
                            });

                            // graphe2
                            // Détruire l'ancienne instance du graphique
                            this.Chart2.destroy();

                            // Mettre à jour les données du graphique
                            this.Chart2.data.datasets[0].data = tabquantitesans;

                            // Créer une nouvelle instance du graphique avec les données mises à jour
                            const canvas2 = this.$refs.pieChart;
                            const ctx2 = canvas2.getContext('2d');

                            this.Chart2 = new Chart(ctx2, {
                            type: 'bar',
                            data: this.Chart2.data,
                            options: {}
                            });

                            //graph 3
                            // Détruire l'ancienne instance du graphique
                            this.Chart3.destroy();

                            // Mettre à jour les données du graphique
                            this.Chart3.data.datasets[0].data = tabquantiteavec;

                            // Créer une nouvelle instance du graphique avec les données mises à jour
                            const canvas3 = this.$refs.pieChart2;
                            const ctx3 = canvas3.getContext('2d');

                            this.Chart3 = new Chart(ctx3, {
                            type: 'bar',
                            data: this.Chart3.data,
                            options: {}
                            });
                        
                        })
                        .catch();


                    },
                    supprhisto(){
                    let link='http://127.0.0.1:8000/api/supprhisto?event='+id;
                    fetch(link, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                    }).then(response => response.json())
                    .then(data => data)
                    .catch();
                    this.actualiser();

                }
            }

    }).mount('#contentstock')

    const creationproduit= Vue.createApp({
        data(){
            return {
                message: 'Test',
                nom:'Produit',
                quantite:0,
                prix:0,
                alcool:'alcool'
            }
        },
        methods:{
            creer(){
                console.log(this.alcool);

                let link='http://127.0.0.1:8000/api/creerstock?event='+id+'&quantite='+this.quantite+'&nom='+this.nom+'&prix='+this.prix+'&alcool='+this.alcool;
                fetch(link, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
                }).then(response => response.json())
                .then(data => data)
                .catch();

            lesproduits.actualiser();
            send();
            }
        }
    }).mount('#creationproduit')

lesproduits.actualiser();



//temps réel socket
var socket = io('localhost:3000');

var sendstock = function (){

    console.log('modif stock');
    socket.emit('stockmodification', {id:id})
}

var receivestock = function(data){
    if(data.id==id){
        lesproduits.actualiser();
        lesproduits.update();
        console.log('stock modifié');
    }
}

socket.on('stockmodification' , receivestock);


</script>
