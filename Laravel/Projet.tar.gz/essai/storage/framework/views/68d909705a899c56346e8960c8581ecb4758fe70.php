<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $associations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $association): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h3>Nom de l'association: <u><?php echo e($association->Nom); ?></u></h3>
    <br>
    <h4><i><?php echo e($association->description); ?></i></h4>
    <br>
   <?php if(!$ev->isEmpty()): ?>
        <h3>Liste des événements associés:</h3>
        <br><br>
        <?php $__currentLoopData = $ev; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <table border="0">
            <ol>
        <b><li><tr><td><h3><b><u><?php echo e($e->Nom); ?></u></h3></td></tr>
        <tr><td> <h4><i><?php echo e($e->Description); ?></i></h4></td></tr>
            <tr><td> <h4><?php echo e($e->Date); ?></h4></td></tr>
                <tr><td> <h4><?php echo e($e->Lieu); ?></h4></td></tr>
        </table>
        <br>
        <br>
        <br>
    </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ol>
    <?php else: ?>
        <h4>Il n'y a pas d'évènements pour cette association. N'hésitez donc pas à <u><a href="<?php echo e(url('/')); ?>/<?php echo e($personne->Identifiant); ?>/ajout_event">en créer un</a></u>!</h4>
        <br>
        <br>
        <br>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php echo $__env->make('partiechatasso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('gabari', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/essai/essai/resources/views/infosassoc.blade.php ENDPATH**/ ?>