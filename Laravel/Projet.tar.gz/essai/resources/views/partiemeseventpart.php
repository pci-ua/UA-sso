<section id="meseventpart">
    <div class="events" v-for="event in evenementsPart">
        <a :href="url +/ParticipationEvenement/+ event.id" >
            <div>
                <h2>{{event.Nom}}</h2>
                <div class="infoevent">
                <p>{{event.Date}}</p>
                <p>{{event.Lieu}}</p>
                <button>info</button></div>
            </div>
        </a>
    </div>
</section>


<script>
    var Url=window.location.pathname;

    var url=window.location;
    var identifiant=Url.split('/')[1];
    console.log('participant');
    console.log(url);
    const leseventsparticipant= Vue.createApp({
        data(){
            return {
                evenementsPart: [],
                id:[],
                url: window.location
            }
        },
        methods:{
                actualiser() {
                    
                    fetch('http://127.0.0.1:8000/api/getidpersonne?identifiant='+identifiant, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                    }).then(response => response.json())
                    .then(data => {
                        this.id=[data];

                        fetch('http://127.0.0.1:8000/api/evenementsPers?id='+this.id, {
                        method: 'GET',
                        headers: {
                            'Content-Type': 'application/json'
                        }
                        }).then(response => response.json())
                        .then(data => {
                            this.evenementsPart=data;
                        })
                        .catch(error => console.log(error))
                        })
                    .catch(error => console.log(error))

                }
                
        }
    }).mount('#meseventpart')
leseventsparticipant.actualiser();

</script>