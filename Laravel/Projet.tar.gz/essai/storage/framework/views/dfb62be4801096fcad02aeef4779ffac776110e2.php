<?php $__env->startSection('content'); ?>
<h1>Voici vos informations personnelles:</h1><br>
<h3 id="h3">Nom:<?php echo e($personne['Nom']); ?><br>
    Prénom:<?php echo e($personne['Prenom']); ?><br>
    Filière:<?php echo e($personne['Filiere']); ?><br>
    E-mail:<?php echo e($personne['mail']); ?><br><br>
</h3>
<h5><button id="mod">Modifier mes informations!</button>
    <br><br>
    <div id="modinf"></div></h5>

    <script>
        var mod = document.getElementById('mod');
        mod.addEventListener('click', function(){
          html=`Choisissez les informations à modifier:<br>
          <form id="update-form" action="<?php echo e(route('update.informations', ['identifiant' => $personne['Identifiant']])); ?>" method="POST">
  <?php echo csrf_field(); ?>
          <table>
            <tr><td> <input type="hidden" id="id" name="id" value="<?php echo e($personne['Identifiant']); ?>"></td></tr>
           <tr><td> Nom:<input type = "text" name="nom"></td></tr>
           <tr><td> Prenom:<input type = "text" name="prenom"></td></tr>
            <tr><td> Filière:<input type = "text" name="filiere"></td></td></tr>
                <tr><td> E-mail:<input type = "text" name="mail"></td></td></tr></table>
       <br><br> <input type="submit" value="Valider les nouvelles informations">

          </form><br>`;

          modinf.innerHTML = html;
        });

        document.getElementById('update-form').addEventListener('submit', function (e) {
    e.preventDefault(); // Empêche la soumission du formulaire
    const iden = document.getElementById('id');
    // Récupère les données du formulaire
    var formData = new FormData(this);})


    // Envoie une requête AJAX pour mettre à jour les informations
    fetch(`/update-informations/${encodeURIComponent(iden.value)}`, {
    method: this.method,
    body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Mise à jour réussie, mettez à jour les éléments de la page
            var nomElement = document.querySelector('#nom');
            var prenomElement = document.querySelector('#prenom');
            var filiereElement = document.querySelector('#filiere');
            var mailElement = document.querySelector('#mail');

            nomElement.textContent = formData.get('nom');
            prenomElement.textContent = formData.get('prenom');
            filiereElement.textContent = formData.get('filiere');
            mailElement.textContent = formData.get('mail');

        } else {
            // La mise à jour a échoué, affichez un message d'erreur
            alert('La mise à jour a échoué. Veuillez réessayer.');
        }
    })
    .catch(error => {
        console.error('Erreur lors de la mise à jour:', error);
    });


        </script>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('gabari', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/essai/essai/resources/views/profil.blade.php ENDPATH**/ ?>