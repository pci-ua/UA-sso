<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Rejoindre_association extends Model
{

    protected $table = 'Rejoindre_association';
    public $timestamps = false;
    //use HasFactory;
}
