<header>
    <?php if(isset($personne)): ?>
        <h1> <?php echo e($personne->Prenom); ?> <?php echo e($personne['Nom']); ?></h1>
        
    <?php else: ?>
        <h1> Projet Gestion Événement</h1>
    <?php endif; ?>
    <?php if(isset($personne)): ?>
    <ul>
        <a href="#event"><li>Événement</li></a>
        <a href="#asso"><li>Association</li></a>
        <a href="<?php echo e(url('/')); ?>/<?php echo e($personne->Identifiant); ?>/Profil"><li>Mon Compte</li></a>
        <a href="<?php echo e(url('/')); ?>"><li>Déconexion</li></a>
    </ul>
    <?php endif; ?>
</header><?php /**PATH /opt/lampp/htdocs/essai/essai/resources/views/menu.blade.php ENDPATH**/ ?>