<?php

namespace App\Http\Controllers;

use App\Models\Association;
use App\Models\Personne;
use App\Models\Association_personne;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
        use App\Mail\ConfirmationMail;
use Illuminate\Support\Facades\DB;

class InvitationController extends Controller
{
    public function listeinv($identifier)
    {
        // Récupérer l'ID de la personne en utilisant l'identifiant
        $personneId = Personne::where('identifiant', $identifier)->value('id');
        $listeass = DB::table('association_personnes')
        ->join('associations', 'association_personnes.association_nom', '=', 'associations.nom')
        ->where('association_personnes.personne_id', $personneId)
        ->pluck('associations.nom')
        ->toArray();
        // Récupérer les invitations envoyées par la personne en utilisant l'ID de la personne
        $listeinv = DB::table('invitations')
            ->where('id_invitee', $personneId)
            ->get();
// Récupérer l'identifiant de la personne invitante pour chaque invitation


$personnesInvitantes = DB::table('invitations')
    ->join('personnes', 'personnes.id', '=', 'invitations.id_invitant')
    ->where('id_invitee', $personneId)
    ->pluck('personnes.identifiant');


        // Retourner la vue 'welcome' avec les données '$listeinv', '$identifier' et '$personneInvitante'
        return view('welcome', [
            'listeinv' => $listeinv,
            'identifier' => $identifier,
            'personneInvitante' => $personnesInvitantes,
            'listeass'=>$listeass
        ]);

    }


}



