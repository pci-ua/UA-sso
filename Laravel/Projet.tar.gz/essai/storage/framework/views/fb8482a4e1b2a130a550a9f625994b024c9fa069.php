<?php $__env->startSection('content'); ?>

<section id="eventencours">
    <h2>Evenement en cours</h2>
    <div id="info">
        <h2><?php echo e($event->Nom); ?></h2>
        <p>Consommation: <?php echo e($part->Consommation); ?></p>
        <div id="infosoirée">
            <h3>Notification:</h3>
            <p id="notif"><?php echo e($event->Notification); ?></p>
        </div>
    </div>
</section>

<section class="gestionstock">
    <?php if(isset($stock[0])): ?>
        
        <h2>Boisson disponible:</h2>
        <table>
            <thead>
                <tr>
                    <th>Produit</th>
                    <th>Prix</th>
                </tr>
            </thead>
        </table>
        <h4 style="margin-top:5px; text-decoration: underline;">Alcool</h4>
            <table>
                <thead>
                </thead>
                <tbody>

                <?php $__currentLoopData = $stock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($produit->alcool=="alcool"): ?>   
                        <tr>
                            <td><?php echo e($produit->nom); ?></td>
                            <td><?php echo e($produit->prix); ?>€</td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <h4 style="margin-top:5px; text-decoration: underline;">Sans alcool</h4>
            <table>
                <thead>
                </thead>
                <tbody>

                <?php $__currentLoopData = $stock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($produit->alcool=="sans"): ?>   
                        <tr>
                            <td><?php echo e($produit->nom); ?></td>
                            <td><?php echo e($produit->prix); ?>€</td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

    <?php endif; ?>
</section>
<?php echo $__env->make('partiechatevent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('partieneplusparticiperevent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    var socket = io('localhost:3000');

    var receivenotif = function(data){
        if(data.id==id){
            let link='http://127.0.0.1:8000/api/notifactuel?event='+id;
            fetch(link, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
            })
            .then(response => response.json())
            .then(data => {
                alert('Nouvelle information: \n'+data);
                var notification = document.getElementById("notif");
                notification.innerHTML = data;
            })
            .catch(error => {console.error('Une erreur s\'est produite:', error);
            });
        }
    }

    socket.on('notificationevent' , receivenotif);

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('gabari', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/essai/essai/resources/views/event.blade.php ENDPATH**/ ?>