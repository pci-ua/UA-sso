<section id="afficherevenement">
        <div class="evenements" v-for="event in evenements">
            <h5>{{event.Nom}}</h5>
            <p>; {{event.Description}} </p><br>
            <p>| {{event.Lieu}}</p>   
            <button @click="rejoindre(event)">Participer</button>
        </div>
</section>

<script>
var Url=window.location.pathname;
var identifiant=Url.split('/')[1];

    const lesevents= Vue.createApp({
        data(){
            return {
                evenements: [],
                evenementsPart: [],
                id:[]
            }
        },
        methods:{
                actualiser() {
                    fetch('http://127.0.0.1:8000/api/evenements', {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                    }).then(response => response.json())
                    .then(data => this.evenements=data)
                    .catch(error => console.log(error))

                    fetch('http://127.0.0.1:8000/api/getidpersonne?identifiant='+identifiant, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                    }).then(response => response.json())
                    .then(data => {
                        this.id=[data];

                        fetch('http://127.0.0.1:8000/api/evenementsPers?id='+this.id, {
                        method: 'GET',
                        headers: {
                            'Content-Type': 'application/json'
                        }
                        }).then(response => response.json())
                        .then(data => {
                            this.evenementsPart=data;
                            this.event();
                        })
                        .catch(error => console.log(error))
                        })
                    .catch(error => console.log(error))

                },
                event(){
                    
                    console.log(this.evenements);
                    //this.evenements = this.evenements.filter(element => console.log(element));//!this.evenementsPart.includes(element));
                    this.evenements = this.evenements.filter(objet1 => !this.evenementsPart.some(objet2 => objet2.id === objet1.id));
                    //console.log(this.evenements);

                },
                rejoindre(event){
                    link='http://127.0.0.1:8000/api/ajoutparticipant?';
                    link+='event='+JSON.stringify(event);
                    link+='&id='+this.id;
                    console.log(link);
                    fetch(link, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                    }).then(response => response.json())
                    .then(data => console.log(data))
                    .catch(error => console.log(error))
                    this.actualiser();

                    leseventsparticipant.actualiser();
                },
                
        }
    }).mount('#afficherevenement')
lesevents.actualiser();

</script>