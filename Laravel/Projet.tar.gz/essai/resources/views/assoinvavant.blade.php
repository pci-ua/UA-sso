@extends('gabari')

@section('content')
<h1>Invitation</h1>
<form action="{{ url('/')}}/{{$identifier}}/inviterAssociation" method="post" id="invitation-form">
    @csrf
    <h3>Id:<input type="text" name="id" id="id-input"/>&nbsp;&nbsp;&nbsp;</h3>&nbsp;&nbsp;&nbsp;<h3><div id="personne-nom"></div></h3>
    <br><br><br>
    <h2>Liste de vos associations:</h2>
    <select name="asso">
        <option value="---" selected>---</option>
        @foreach ($listeass as $n)
        <option value="{{$n}}">{{$n}}</option>
        @endforeach
    </select>
    <br><br><br>
    <input type="button" value="Inviter!" id="submit-button"/>
</form>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        $('#submit-button').click(function() {
            var formData = $('#invitation-form').serialize();
            $.ajax({
                type: 'POST',
                url: 'http://127.0.0.1:8000/api/{{$identifier}}/inviterAssociation',
                data: formData,
                success: function(response) {
                    // handle success response
                    alert('Invitation envoyée avec succès!');
                },
                error: function(xhr, status, error) {
                    // handle error response
                    alert('Erreur: ' + error);
                }
            });
        });
    });
    const idInput = document.getElementById('id-input');
const nameDiv = document.getElementById('personne-nom');
/*
idInput.addEventListener('input', function() {
  const id = idInput.value;
  if (id) {
    fetch('/get-person-name-ajax/' + encodeURIComponent(id))
      .then(response => response.text())
      .then(name => {
        nameDiv.innerHTML = name.replace(/\n/g, '<br>');
      })
      .catch(error => {
        console.error('Error:', error);
      });
  } else {
    nameDiv.textContent = '';
  }
});*/




</script>

@endsection
