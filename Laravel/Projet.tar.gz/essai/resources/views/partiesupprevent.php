
<div class="suppr">
    <button id="suppr">Supprimer l'événement</button>
</div>
<script>

let button = document.querySelector('#suppr');

button.addEventListener('click', () => {
    let link='http://127.0.0.1:8000/api/supprevenement?event='+id;
    fetch(link, {
    method: 'GET',
    headers: {
        'Content-Type': 'application/json'
    }
    }).then(response => response.json())
    .then(data => {
        console.log('test avant');
        if(data){
            const host = window.location.host; // Hôte (par exemple, "www.example.com")
            const pathname = window.location.pathname; // Chemin d'accès (par exemple, "/ma-page.html")

            console.log('test apres');
            const newUrl ='http://'+host+'/'+pathname.split('/')[1];
            window.location.href=newUrl;
        }
    })
    .catch();
                    
    

});
</script>