<?php $__env->startSection('content'); ?>
<section id="corps">

    <?php echo $__env->make('qrpartie', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section id="information">
        <div id="prochainevents" class="conteneurinfo">
            <h2>Participation aux Événements: </h2>
            <?php echo $__env->make('partiemeseventpart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <?php echo $__env->make('partieinvit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </section>

    <section id="mesevent">
        <?php if(isset($mesevents[0])): ?>
            <h2>Mes Événements</h2>
           
                <?php $__currentLoopData = $mesevents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $monevent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="monevent">
                        <h3><?php echo e($monevent['Nom']); ?></h3>
                        <div class="infomonevent">
                            <h4>Participant Max</h4>
                            <p><?php echo e($monevent['nb_max']); ?></p>
                        </div>
                        <div class="infomonevent">
                            <h4>Information:</h4>
                            <p><?php echo e($monevent['Lieu']); ?></p>
                            <p><?php echo e($monevent['Date']); ?></p>
                            <p><?php echo e($monevent['Description']); ?></p>
                        </div>
                        <div><a href="<?php echo e(url('/')); ?>/<?php echo e($personne['Identifiant']); ?>/<?php echo e($monevent['id']); ?>"><input type="button" value="Gestion"></a></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <h4>Pas d'événement</h4>
        <?php endif; ?>
        <a href="<?php echo e(url('/')); ?>/<?php echo e($personne['Identifiant']); ?>/ajout_event"><svg clip-rule="evenodd" fill-rule="evenodd" stroke-linejoin="round" stroke-miterlimit="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="m12.002 2c5.518 0 9.998 4.48 9.998 9.998 0 5.517-4.48 9.997-9.998 9.997-5.517 0-9.997-4.48-9.997-9.997 0-5.518 4.48-9.998 9.997-9.998zm0 1.5c-4.69 0-8.497 3.808-8.497 8.498s3.807 8.497 8.497 8.497 8.498-3.807 8.498-8.497-3.808-8.498-8.498-8.498zm-.747 7.75h-3.5c-.414 0-.75.336-.75.75s.336.75.75.75h3.5v3.5c0 .414.336.75.75.75s.75-.336.75-.75v-3.5h3.5c.414 0 .75-.336.75-.75s-.336-.75-.75-.75h-3.5v-3.5c0-.414-.336-.75-.75-.75s-.75.336-.75.75z" fill-rule="nonzero"/></svg></a>
    </section>

    <section id="membreAsso">
        <h2>Association</h2>

        <div id="listeasso">
            <?php if(isset($membres[0])): ?>
                <?php $__currentLoopData = $membres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <div class="monasso">
                        <h3><?php echo e($membre->Nom); ?></h3>
                        <!--<div class="infomonasso">
                            <a href=""><h4>Les Evenement de l'asso</h4></a>
                        </div>-->
                        <div><a href="<?php echo e(url('/')); ?>/<?php echo e($personne['Identifiant']); ?>/Associations/<?php echo e($membre->Nom); ?>/Infos"><input type="button" value="info"></a></div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endif; ?>
        </div>
        <a href="<?php echo e(url('/')); ?>/<?php echo e($personne['Identifiant']); ?>/ajout_association"><svg clip-rule="evenodd" fill-rule="evenodd" stroke-linejoin="round" stroke-miterlimit="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="m12.002 2c5.518 0 9.998 4.48 9.998 9.998 0 5.517-4.48 9.997-9.998 9.997-5.517 0-9.997-4.48-9.997-9.997 0-5.518 4.48-9.998 9.997-9.998zm0 1.5c-4.69 0-8.497 3.808-8.497 8.498s3.807 8.497 8.497 8.497 8.498-3.807 8.498-8.497-3.808-8.498-8.498-8.498zm-.747 7.75h-3.5c-.414 0-.75.336-.75.75s.336.75.75.75h3.5v3.5c0 .414.336.75.75.75s.75-.336.75-.75v-3.5h3.5c.414 0 .75-.336.75-.75s-.336-.75-.75-.75h-3.5v-3.5c0-.414-.336-.75-.75-.75s-.75.336-.75.75z" fill-rule="nonzero"/></svg></a>
    </section>

    <section id="event">
        <div>
            <h3>Rejoindre événement:</h3>
        </div>
        
        <?php echo $__env->make('rejoindreeventpartie', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </section>
    <?php echo $__env->make('rejoindreAssopartie', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<section id="mesdemande">
    <h2>Mes demandes en cours</h2>
    <div id="listeasso">
        <?php if(isset($demandes[0])): ?>
            <?php $__currentLoopData = $demandes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $demande): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <div class="monasso">
                    <h3><?php echo e($demande->Nom); ?></h3>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php endif; ?>
    </div>
</section>


</section>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('gabari', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/essai/essai/resources/views/accueilPersonne.blade.php ENDPATH**/ ?>