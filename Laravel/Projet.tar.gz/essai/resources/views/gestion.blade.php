
@extends('gabari')


@section('content')
<section class="gestionstock">

<h1 style="border: solid; padding:5px; margin-bottom:15px">{{$event->Nom}}</h1>
@include('partiestock')
</section>

<section class="gestion barre">
    @include('partiemessage')

    @include('partiegestionparticipant')
</section>

@include('partiesupprevent')
@include('partiechatevent')
@endsection
