@extends('gabari')


@section('content')
<style>
    #formulaire {
        display: flex;
        flex-direction: column;
        align-items: center;
        margin-top: 50px;
        margin-bottom: 200px;
    }
    form{
        display: flex;
        flex-direction: column;
        align-items: center;
        background-color: white;
        width: 50%;
    }
</style>
@if ($type =='asso')
    <div id="formulaire"><h3>Créer Association</h3>
    <form action="{{url('/')}}/{{$personne['Identifiant']}}/ajout_association" method="post">
        {{ csrf_field() }}
        <label for="nom">Nom :</label>
        <input type="text" name="nom">

        <label for="prenom">Description:</label>
        <input type="text" name="description">

        <button type="submit">Créer</button>
    
    </form>
</div>
@else
<div id="formulaire">
    <h3>Créer Événement</h3>
    <form action="{{url('/')}}/{{$personne['Identifiant']}}/ajout_event" method="post">
        {{ csrf_field() }}
        <label for="nom">Nom :</label>
        <input type="text"name="nom">

        <label for="description">Description :</label>
        <input type="text" name="description">

        <label for="date">Date :</label>
        <input type="date" name="date">

        <label for="max">Nombre maximum :</label>
        <input type="number" name="max">

        <label for="lieu">Lieu</label>
        <input type="text" name="lieu" >

        <label for="Asso">Association</label>
        <select id="choix-couleur" name="Asso">
            <option value="Aucune"></option>
            @foreach ($Assos as $Asso)    
                <option value="{{$Asso->Nom}}">{{$Asso->Nom}}</option>
            @endforeach
        </select>

        <button type="submit">Créer</button>
    </form>
</div>
@endif
@endsection