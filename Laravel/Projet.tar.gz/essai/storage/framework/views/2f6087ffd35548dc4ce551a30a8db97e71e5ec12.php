<?php $__env->startSection('content'); ?>
    
    <h1><?php echo e($message); ?></h1>
    <?php if(isset($personne)): ?>
        <a href="<?php echo e(url('/')); ?>/<?php echo e($personne['Identifiant']); ?>"><button>Retour</button></a>
    <?php else: ?>
        <a href="<?php echo e(url('/')); ?>"><button>Retour</button></a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('gabari', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/essai/essai/resources/views/test.blade.php ENDPATH**/ ?>