<?php

namespace App\Http\Controllers;

use App\Models\Association;
use App\Models\Personne;
use App\Models\Invitations;
use App\Models\Association_personne;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
        use App\Mail\ConfirmationMail;
use Illuminate\Support\Facades\DB;

class AssociationControllerBis extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function listeass($identifier)
    {
        $Personne=Personne::all();
        $pers=Personne::where('Identifiant','=', $identifier)->get()[0];

        
        // Récupérer l'ID de la personne en utilisant l'identifiant
        $personneId = Personne::where('identifiant', $identifier)->value('id');

        // Récupérer les associations de la personne en utilisant l'ID de la personne
        $listeass = DB::table('association_personnes')
            ->join('Association', 'association_personnes.association_nom', '=', 'Association.Nom')
            ->where('association_personnes.personne_id', $personneId)
            ->pluck('Association.Nom')
            ->toArray();

        // Retourner la vue 'nom_de_vue' avec les données '$listeass' et '$identifier'
        return view('assoinv', ['personne'=>$pers,'listeass' => $listeass, 'personneid' => $personneId, 'identifier' => $identifier, 'tous' => $Personne]);
    }



    public function envoyerInvitation(Request $request, $identifier)
    {
        // Pour avoir l'id de la personne à partir de son identifiant
        $personneId = Personne::where('identifiant', $identifier)->value('id');
        $personneNom = Personne::where('identifiant', $identifier)->value('nom');

        // Get the person's list of associations
        $listeass = $this->listeass($identifier);

        // Get the form data
        $asso = $request->input('asso');
        $id = $request->input('id');

        // Check if the ID is valid
        if (!is_numeric($id) || $id <= 0) {
            // Redirect with an error message if the ID is not valid
            return redirect()->route('assoinv', ['identifier' => $identifier])->with('error', 'L\'ID n\'est pas valide. Veuillez entrer un entier supérieur à 0.');
        }

        // Get the corresponding association
        $association = Association::where('nom', $asso)->first();

        // Check if the association exists
        if (!$association) {
            // Redirect with an error message if the association does not exist
            return redirect()->route('assoinv', ['identifier' => $identifier])->with('error', 'L\'association n\'existe pas. Veuillez sélectionner une association valide.');
        }

        // Check if the ID is already in the members field of the association
        $members = DB::table('association_personnes')
            ->where('association_nom', $asso)
            ->pluck('personne_id')
            ->toArray();
        if (in_array($id, $members)) {
            // Redirect with an error message if the ID is already in the members field
            return redirect()->route('assoinv', ['identifier' => $identifier])->with('error', 'L\'ID est déjà dans les membres de l\'association.');
        }
        DB::table('invitations')->insert([
            'id_invitee' => $id,
            'id_invitant' => $personneId,
            'nom_assoc' => $asso
        ]);

        // Et maintenant,on se redirige!
        return redirect()->route('assoinv', ['identifier' => $identifier,'personneNom'=>$personneNom])->with('success', 'Invitation envoyée avec succès !');
    }

  public function creationassoc(Request $request){
        // Récupérer les données du formulaire
        $nom = $request->input('nom');
        $description = $request->input('desc');

        // Vérifier si l'association existe déjà
        $existingAssoc = Association::where('nom', $nom)->first();
        if ($existingAssoc) {
            // Rediriger avec un message d'erreur si l'association existe déjà
            return redirect()->route('creationassoc')->with('error', 'L\'association existe déjà. Veuillez choisir un autre nom.');
        }

        // Créer une nouvelle association
        $association = new Association;
        $association->nom = $nom;
        $association->description = $description;
        $association->save();

        // Rediriger avec un message de succès
        return redirect()->route('creationassoc')->with('success', 'L\'association a été créée avec succès !');
    }



    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
