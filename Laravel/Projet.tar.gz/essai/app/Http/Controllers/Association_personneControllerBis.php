<?php

namespace App\Http\Controllers;

use App\Models\Association;
use App\Models\Personne;
use App\Models\Association_personne;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
        use App\Mail\ConfirmationMail;
use Illuminate\Support\Facades\DB;

class Association_personneController extends Controller{
public function ajouterPersonne(Request $request, $identifier, $assoNom)
{
    $id = Personne::where('identifiant', $identifier)->value('id');
    $asso = Association::where('nom', $assoNom)->first();

    DB::table('association_personnes')->insert([
        'personne_id' => $id,
        'association_nom' => $asso->nom
    ]);

    $message = "Vous appartenez maintenant à l'association $assoNom !";
    return response()->json($message);
}

}
