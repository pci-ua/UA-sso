@extends('gabari')

@section('content')

@foreach ($associations as $association)
    <h3>Nom de l'association: <u>{{$association->Nom}}</u></h3>
    <br>
    <h4><i>{{$association->description}}</i></h4>
    <br>
   @if (!$ev->isEmpty())
        <h3>Liste des événements associés:</h3>
        <br><br>
        @foreach ($ev as $e)
        <table border="0">
            <ol>
        <b><li><tr><td><h3><b><u>{{$e->Nom}}</u></h3></td></tr>
        <tr><td> <h4><i>{{$e->Description}}</i></h4></td></tr>
            <tr><td> <h4>{{$e->Date}}</h4></td></tr>
                <tr><td> <h4>{{$e->Lieu}}</h4></td></tr>
        </table>
        <br>
        <br>
        <br>
    </li>
        @endforeach
</ol>
    @else
        <h4>Il n'y a pas d'évènements pour cette association. N'hésitez donc pas à <u><a href="{{url('/')}}/{{$personne->Identifiant}}/ajout_event">en créer un</a></u>!</h4>
        <br>
        <br>
        <br>
    @endif
@endforeach

@include('partiechatasso')

@endsection
