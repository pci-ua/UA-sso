
@extends('gabari')
<link rel="stylesheet" href="../style.css">
        

@section('content')
    
    <h1>{{$message}}</h1>
@endsection