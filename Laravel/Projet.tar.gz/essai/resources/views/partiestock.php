
    <h1>Gestion Stock</h1>
    <section id="contentstock">
        <div class="produit" v-for="prod in produits">
            <h4>{{prod.nom}}</h4>
            <p>: {{prod.quantite}}   |  </p>
            <input ref="quantite" class="zonenbr" type="number" name="nombreproduit" > 
            <input type="button" value="ajouter" @click="ajout(prod)">
            <input type="button" value="-" @click="moins(prod)">
            <input type="button" value="+" @click="plus(prod)">
        </div>
    </section>
    <section id="creationproduit">
        <label for="nomproduit">Nom:</label>
        <input type="text" name="nomproduit" v-model="nom">
        <label for="nomproduit">Quantité:</label>
        <input type="number" name="nombreproduit" v-model="quantite" >
        <input type="button" value="Creer Produit" @click="creer">
    </section>

<script>


var Url=window.location.pathname;
var id=Url.split('/')[2];

    const lesproduits= Vue.createApp({
        data(){
            return {
                quantite:0,
                produits: [
                ]
            }
        },
        methods:{
                actualiser(){
                    fetch('http://127.0.0.1:8000/api/stock?event='+id, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                    }).then(response => response.json())
                    .then(data => lesproduits.produits=data)
                    .catch(error => lesproduits.produits=[]);

                },
                ajoutdbb(quantite, nom){
                    let link='http://127.0.0.1:8000/api/modifierstock?event='+id+'&quantite='+quantite+'&nom='+nom;
                    fetch(link, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                    }).then(response => response.json())
                    .then(data => data)
                    .catch();
                    this.actualiser();
                },
                ajout(prod){
                    index=this.produits.findIndex(produit=> produit.nom === prod.nom );
                    ajout=parseInt(this.$refs.quantite[index].value);
                    if(Number.isInteger(ajout)){
                        this.ajoutdbb(ajout, prod.nom);
                    }
                },
                plus(prod){
                    /*index=this.produits.findIndex(produit=> produit.nom === prod.nom )
                    this.produits[index].quantite++*/
                    this.ajoutdbb(1,prod.nom);
                },
                moins(prod){
                    /*
                    index=this.produits.findIndex(produit=> produit.nom === prod.nom )
                    this.produits[index].quantite--*/
                    this.ajoutdbb(-1,prod.nom);
                }
            }

    }).mount('#contentstock')

    const creationproduit= Vue.createApp({
        data(){
            return {
                message: 'Test',
                nom:'Produit',
                quantite:0
            }
        },
        methods:{
            creer(){
                let link='http://127.0.0.1:8000/api/creerstock?event='+id+'&quantite='+this.quantite+'&nom='+this.nom;
                fetch(link, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
                }).then(response => response.json())
                .then(data => data)
                .catch();

            lesproduits.actualiser();

            }
        }
    }).mount('#creationproduit')

lesproduits.actualiser();
</script>